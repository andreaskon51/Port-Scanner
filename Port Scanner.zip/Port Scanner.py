import socket
import threading
from queue import Queue

target = "127.0.0.1"  # Replace with the target IP address
num_threads = 100  # Number of threads to use for scanning
open_ports = []

def scan_tcp_ports(start_port, end_port):
    for port in range(start_port, end_port + 1):
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.settimeout(1)  # Adjust the timeout as you see fit
        result = sock.connect_ex((target, port))
        if result == 0:
            try:
                service_name = socket.getservbyport(port)
            except OSError:
                service_name = "Unknown"
            open_ports.append((port, service_name))
        sock.close()

def scan_udp_ports(start_port, end_port):
    for port in range(start_port, end_port + 1):
        sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        sock.settimeout(1)  # Adjust the timeout as you see fit
        result = sock.connect_ex((target, port))
        if result == 0:
            try:
                service_name = socket.getservbyport(port)
            except OSError:
                service_name = "Unknown"
            open_ports.append((port, service_name))
        sock.close()

def worker():
    while not port_queue.empty():
        port_range = port_queue.get()
        scan_tcp_ports(*port_range)
        scan_udp_ports(*port_range)

port_queue = Queue()

# Divide the port range into chunks for distribution among threads
port_ranges = [(1, 1000), (1001, 2000), (2001, 3000), (3001, 4000)]

# Add port ranges to the queue
for port_range in port_ranges:
    port_queue.put(port_range)

# Create and start the threads
threads = []
for _ in range(num_threads):
    t = threading.Thread(target=worker)
    t.start()
    threads.append(t)

# Wait for all threads to complete
for t in threads:
    t.join()

# Print the open ports with their names
for port, service_name in open_ports:
    print(f"Port {port} ({service_name}) is open")